import streamlit as st
import time
import streamlit.components.v1 as components

# Title

st.title('Defect Triage')

title = st.text_input('Test Request', 'Test Request Details')

title = st.text_input('Product Details', 'Product & Sub Product Details')


txt = st.text_area('Description', '''Test Request Complete Details''')

option = st.multiselect(
     'Test Type',
     ['Functional Testing', 'Regression Testing', 'Performance Testing','Integration Testing','E2E Testing', 'All'])

if st.button('SUBMIT'):
    with st.spinner('Wait for it...'):
        time.sleep(2)
    st.success('Done')

    st.warning('45/560 test cases found')

    st.title('Test Case Details')

    with open('app.html') as f:
        data = f.read()
        components.html(data, height=800)








