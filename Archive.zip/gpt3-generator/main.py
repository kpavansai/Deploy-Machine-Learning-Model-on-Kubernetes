import streamlit as st
import openai
from ml_backend import ml_backend

st.markdown("<h1 style='text-align: center; color: brown;'>Test Request</h1>", unsafe_allow_html=True)

st.subheader("Generate Test cases and scripts")

backend = ml_backend()

with st.form(key="form"):
    prompt = st.text_input("Describe the Kind of Test Request you want to be written.")

    start = st.text_area("Begin writing the first few or several words of your Test Request:")

    # slider = st.slider("How many characters do you want your email to be? ", min_value=64, max_value=750)
    # st.text("(A typical email is usually 100-500 characters)")

    submit_button = st.form_submit_button(label='Generate')

    if submit_button:
        with st.spinner("Generating ..."):
            output = backend.generate_email(prompt, start)
        st.subheader("Model Output:")
        st.code(start + output)
